## wrapper electron para teams.

auto install:
```bash
curl -sSL https://raw.githubusercontent.com/limaleonardo/teams-electron/main/autoinstall.sh | bash
```